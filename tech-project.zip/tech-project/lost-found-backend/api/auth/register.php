<?php
include_once '../../config/cors.php';
include_once '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->name) && !empty($data->email) && !empty($data->password)) {
        // Check if user already exists
        $check_query = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(1, $data->email);
        $check_stmt->execute();
        
        if ($check_stmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
        } else {
            $query = "INSERT INTO users (name, email, password, phone) VALUES (?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            
            $hashed_password = password_hash($data->password, PASSWORD_DEFAULT);
            $phone = isset($data->phone) ? $data->phone : null;
            
            $stmt->bindParam(1, $data->name);
            $stmt->bindParam(2, $data->email);
            $stmt->bindParam(3, $hashed_password);
            $stmt->bindParam(4, $phone);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Registration successful']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Registration failed']);
            }
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Name, email and password are required']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
