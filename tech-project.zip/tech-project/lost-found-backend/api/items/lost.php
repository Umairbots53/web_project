<?php
include_once '../../config/cors.php';
include_once '../../config/database.php';
session_start();

$database = new Database();
$db = $database->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $query = "SELECT li.*, u.name as user_name, u.email, c.name as category_name 
                  FROM lost_items li 
                  JOIN users u ON li.user_id = u.id 
                  JOIN categories c ON li.category_id = c.id 
                  WHERE li.status = 'active' 
                  ORDER BY li.created_at DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute();
        $items = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'data' => $items]);
        break;
        
    case 'POST':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $item_name = $_POST['item_name'] ?? '';
        $category_id = $_POST['category_id'] ?? '';
        $description = $_POST['description'] ?? '';
        $date_lost = $_POST['date_lost'] ?? '';
        $location_lost = $_POST['location_lost'] ?? '';
        
        if (empty($item_name) || empty($category_id) || empty($date_lost) || empty($location_lost)) {
            echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
            break;
        }
        
        $image_path = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $upload_dir = '../../uploads/lost/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($_FILES['image']['type'], $allowed_types)) {
                $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $new_filename = uniqid() . '.' . $file_extension;
                $image_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
                    $image_path = 'uploads/lost/' . $new_filename;
                } else {
                    $image_path = null;
                }
            }
        }
        
        $query = "INSERT INTO lost_items (user_id, item_name, category_id, description, date_lost, location_lost, image_path) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        
        if ($stmt->execute([$_SESSION['user_id'], $item_name, $category_id, $description, $date_lost, $location_lost, $image_path])) {
            echo json_encode(['success' => true, 'message' => 'Lost item reported successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to report lost item']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        break;
}
?>
