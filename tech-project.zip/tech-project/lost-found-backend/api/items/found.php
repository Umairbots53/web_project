<?php
include_once '../../config/cors.php';
include_once '../../config/database.php';
session_start();

$database = new Database();
$db = $database->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $query = "SELECT fi.*, u.name as user_name, u.email, c.name as category_name 
                  FROM found_items fi 
                  JOIN users u ON fi.user_id = u.id 
                  JOIN categories c ON fi.category_id = c.id 
                  WHERE fi.status = 'active' 
                  ORDER BY fi.created_at DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute();
        $items = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'data' => $items]);
        break;
        
    case 'POST':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $item_name = $_POST['item_name'] ?? '';
        $category_id = $_POST['category_id'] ?? '';
        $description = $_POST['description'] ?? '';
        $date_found = $_POST['date_found'] ?? '';
        $location_found = $_POST['location_found'] ?? '';
        
        if (empty($item_name) || empty($category_id) || empty($date_found) || empty($location_found)) {
            echo json_encode(['success' => false, 'message' => 'All required fields must be filled']);
            break;
        }
        
        $image_path = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $upload_dir = '../../uploads/found/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($_FILES['image']['type'], $allowed_types)) {
                $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $new_filename = uniqid() . '.' . $file_extension;
                $image_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
                    $image_path = 'uploads/found/' . $new_filename;
                } else {
                    $image_path = null;
                }
            }
        }
        
        $query = "INSERT INTO found_items (user_id, item_name, category_id, description, date_found, location_found, image_path) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        
        if ($stmt->execute([$_SESSION['user_id'], $item_name, $category_id, $description, $date_found, $location_found, $image_path])) {
            echo json_encode(['success' => true, 'message' => 'Found item reported successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to report found item']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        break;
}
?>
