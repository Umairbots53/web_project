<?php
include_once '../../config/cors.php';
include_once '../../config/database.php';
session_start();

$database = new Database();
$db = $database->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $item_id = $_GET['item_id'] ?? null;
        $item_type = $_GET['item_type'] ?? null;
        $other_user_id = $_GET['other_user_id'] ?? null;
        
        if ($item_id && $item_type && $other_user_id) {
            $query = "SELECT cm.*, u.name as sender_name 
                      FROM chat_messages cm 
                      JOIN users u ON cm.sender_id = u.id 
                      WHERE cm.item_id = ? AND cm.item_type = ? 
                      AND ((cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?))
                      ORDER BY cm.created_at ASC";
            
            $stmt = $db->prepare($query);
            $stmt->execute([$item_id, $item_type, $_SESSION['user_id'], $other_user_id, $other_user_id, $_SESSION['user_id']]);
            $messages = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'data' => $messages]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Missing parameters']);
        }
        break;
        
    case 'POST':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        
        if (!empty($data->receiver_id) && !empty($data->item_id) && !empty($data->item_type) && !empty($data->message)) {
            $query = "INSERT INTO chat_messages (sender_id, receiver_id, item_id, item_type, message) 
                      VALUES (?, ?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            
            if ($stmt->execute([$_SESSION['user_id'], $data->receiver_id, $data->item_id, $data->item_type, $data->message])) {
                echo json_encode(['success' => true, 'message' => 'Message sent successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to send message']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'All fields are required']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        break;
}
?>
