<?php
include_once '../../config/cors.php';
include_once '../../config/database.php';
session_start();

$database = new Database();
$db = $database->getConnection();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $query = "SELECT c.*, u.name as claimer_name, u.email as claimer_email,
                         fi.item_name as found_item_name, li.item_name as lost_item_name
                  FROM claims c 
                  JOIN users u ON c.claimer_id = u.id 
                  LEFT JOIN found_items fi ON c.found_item_id = fi.id
                  LEFT JOIN lost_items li ON c.lost_item_id = li.id
                  WHERE c.claimer_id = ? OR 
                        (c.found_item_id IN (SELECT id FROM found_items WHERE user_id = ?)) OR
                        (c.lost_item_id IN (SELECT id FROM lost_items WHERE user_id = ?))
                  ORDER BY c.created_at DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
        $claims = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'data' => $claims]);
        break;
        
    case 'POST':
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            break;
        }
        
        $data = json_decode(file_get_contents("php://input"));
        
        $found_item_id = isset($data->found_item_id) ? $data->found_item_id : null;
        $lost_item_id = isset($data->lost_item_id) ? $data->lost_item_id : null;
        $message = $data->message ?? '';
        
        if (($found_item_id || $lost_item_id) && !empty($message)) {
            $query = "INSERT INTO claims (claimer_id, found_item_id, lost_item_id, message) 
                      VALUES (?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            
            if ($stmt->execute([$_SESSION['user_id'], $found_item_id, $lost_item_id, $message])) {
                echo json_encode(['success' => true, 'message' => 'Claim submitted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to submit claim']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Item ID and message are required']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        break;
}
?>
