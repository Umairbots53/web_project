const API_BASE_URL = 'http://localhost/lost-found-backend/api';


class LostFoundAPI {
    async login(email, password) {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/login.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async register(name, email, password, phone = '') {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/register.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password, phone }),
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Registration error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async logout() {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/logout.php`, {
                method: 'POST',
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Logout error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async submitLostItem(formData) {
        try {
            const response = await fetch(`${API_BASE_URL}/items/lost.php`, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Submit lost item error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async submitFoundItem(formData) {
        try {
            const response = await fetch(`${API_BASE_URL}/items/found.php`, {
                method: 'POST',
                body: formData,
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Submit found item error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async getFoundItems() {
        try {
            const response = await fetch(`${API_BASE_URL}/items/found.php`, {
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Get found items error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async getLostItems() {
        try {
            const response = await fetch(`${API_BASE_URL}/items/lost.php`, {
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Get lost items error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async getCategories() {
        try {
            const response = await fetch(`${API_BASE_URL}/items/categories.php`, {
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Get categories error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async sendMessage(messageData) {
        try {
            const response = await fetch(`${API_BASE_URL}/chat/messages.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(messageData),
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Send message error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async getMessages(itemId, itemType, otherUserId) {
        try {
            const response = await fetch(`${API_BASE_URL}/chat/messages.php?item_id=${itemId}&item_type=${itemType}&other_user_id=${otherUserId}`, {
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Get messages error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async submitClaim(claimData) {
        try {
            const response = await fetch(`${API_BASE_URL}/claims/claims.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(claimData),
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Submit claim error:', error);
            return { success: false, message: 'Network error' };
        }
    }

    async getClaims() {
        try {
            const response = await fetch(`${API_BASE_URL}/claims/claims.php`, {
                credentials: 'include'
            });
            return await response.json();
        } catch (error) {
            console.error('Get claims error:', error);
            return { success: false, message: 'Network error' };
        }
    }
}

const api = new LostFoundAPI();
